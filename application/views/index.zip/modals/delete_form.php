<h3 align="center"> Anda yakin ingin Menghapus Data ? </h3>
<div class="row">
  <div class="col-md-6" align="left">
    <button type="button" class="btn pull-left btn-block btn-md btn-info round" data-dismiss="modal"><i class="fa fa-close"></i> Tutup</button>
  </div>
  <div class="col-md-6" align="right">
    <button type="submit" class="btn btn-block pull-right btn-md btn-danger round"><i class="fa fa-trash"></i> Hapus</button>
  </div>
</div>